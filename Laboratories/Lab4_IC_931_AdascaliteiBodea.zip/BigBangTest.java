package org.example;

import domain.Nota;
import domain.Student;
import domain.Tema;
import org.junit.Before;
import org.junit.Test;
import repository.NotaXMLRepository;
import repository.StudentXMLRepository;
import repository.TemaXMLRepository;
import service.Service;
import validation.NotaValidator;
import validation.StudentValidator;
import validation.TemaValidator;
import validation.Validator;

import java.io.PrintWriter;

import static org.junit.Assert.assertEquals;

public class BigBangTest
{
    private Service service;
    /**
     * Rigorous Test :-)
     */
    @Before
    public void setUp() throws Exception {
        Validator<Student> studentValidator = new StudentValidator();
        Validator<Tema> temaValidator = new TemaValidator();
        Validator<Nota> notaValidator = new NotaValidator();

        PrintWriter writer = new PrintWriter("testStudenti.xml");
        writer.print("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" +
                "<Entitati>\n" +
                "    <student ID=\"1\">\n" +
                "        <Nume>Adonis</Nume>\n" +
                "        <Grupa>931</Grupa>\n" +
                "    </student>\n" +
                "</Entitati>\n");
        writer.close();

        writer = new PrintWriter("testTeme.xml");
        writer.print("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" +
                "<Entitati>\n" +
                "<tema ID=\"1\">\n" +
                "<Descriere>File</Descriere>\n" +
                "<Deadline>7</Deadline>\n" +
                "<Startline>6</Startline>\n" +
                "</tema>\n" +
                "</Entitati>\n");
        writer.close();

        writer = new PrintWriter("testNote.xml");
        writer.print("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" +
                "<Entitati>\n" +
                "</Entitati>\n");
        writer.close();

        StudentXMLRepository fileRepository1 = new StudentXMLRepository(studentValidator, "testStudenti.xml");

        TemaXMLRepository fileRepository2 = new TemaXMLRepository(temaValidator, "testTeme.xml");
        NotaXMLRepository fileRepository3 = new NotaXMLRepository(notaValidator, "testNote.xml");

        service = new Service(fileRepository1, fileRepository2, fileRepository3);
    }

    @Test
    public void testAddStudent(){
        assertEquals(1, service.saveStudent("foobar", "的", 931));
    }

    @Test
    public void testAddAssignment(){
        assertEquals(1, service.saveTema("2", "Setup", 7, 5));
    }

    @Test
    public void testAddGrade(){
        assertEquals(1, service.saveNota("1", "1", 8, 7, "ok"));
    }

    @Test
    public void testBigBang(){
        assertEquals(1, service.saveStudent("2", "Alex", 931));
        assertEquals(1, service.saveTema("3", "bla", 7, 5));
        assertEquals(1, service.saveNota("2", "3", 8, 7, "ok"));
    }
}
