package org.example;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Unit test for simple App.
 */
public class AppTest {

    private DeleteAllFromInterval service;

    public AppTest() {
    }

    @Before
    public void setup() {
        this.service = new DeleteAllFromInterval();
    }

    @Test
    public void test0() {

        try {
            int ret = service.deleteAllFromInterval(new ArrayList<>(), 3, 4);
            assert ret == -1;
        } catch (MyValueException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test1() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(2);
            int ret = service.deleteAllFromInterval(list, 1, 2);
            assert ret == 1;
        } catch (MyValueException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test2() {
        try {
            //cazu bun
            ArrayList<Integer> list = new ArrayList<>();
            list.add(2);
            list.add(3);
            list.add(4);
            int ret = service.deleteAllFromInterval(list, 1, 3);
            assert ret == 1;
        } catch (MyValueException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test3() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(2);
            list.add(3);
            int ret = service.deleteAllFromInterval(list, 4, 5);
            assert ret == -1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test4() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(4);
            list.add(5);
            int ret = service.deleteAllFromInterval(list, 1, 2);
            assert ret == -1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test5() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(4);
            list.add(5);
            int ret = service.deleteAllFromInterval(list, 4, 4);
            assert ret == -1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test6() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(4);
            list.add(5);
            int ret = service.deleteAllFromInterval(list, 6, 4);
            assert ret == -1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void test7() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(4);
            list.add(5);
            int ret = service.deleteAllFromInterval(list, 4, 2);
            assert ret == -1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test8() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(2);
            list.add(3);
            list.add(4);
            int ret = service.deleteAllFromInterval(list, 2, 3);
            assert ret == 1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void test9() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(2);
            list.add(3);
            list.add(4);
            int ret = service.deleteAllFromInterval(list, 1, 3);
            assert ret == 1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void test10() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(2);
            list.add(3);
            list.add(4);
            int ret = service.deleteAllFromInterval(list, 1, 4);
            assert ret == 1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void test11() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(2);
            list.add(3);
            list.add(4);
            int ret = service.deleteAllFromInterval(list, 1, 5);
            assert ret == 1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }
    @Test
    public void test12() {
        try {
            ArrayList<Integer> list = new ArrayList<>();
            list.add(2);
            list.add(3);
            list.add(4);
            int ret = service.deleteAllFromInterval(list, 2, 4);
            assert ret == 1;
        } catch (
                MyValueException e) {
            e.printStackTrace();
        }
    }
}

