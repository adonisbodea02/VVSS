package org.example;

import domain.Nota;
import domain.Student;
import domain.Tema;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import repository.NotaXMLRepository;
import repository.StudentXMLRepository;
import repository.TemaXMLRepository;
import service.Service;
import validation.NotaValidator;
import validation.StudentValidator;
import validation.TemaValidator;
import validation.Validator;

import java.io.File;
import java.io.PrintWriter;

import static org.junit.Assert.*;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    private Service service;
    /**
     * Rigorous Test :-)
     */
    @Before
    public void setUp() throws Exception {
        Validator<Student> studentValidator = new StudentValidator();
        Validator<Tema> temaValidator = new TemaValidator();
        Validator<Nota> notaValidator = new NotaValidator();

        PrintWriter writer = new PrintWriter("testStudenti.xml");
        writer.print("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" +
                "<Entitati>\n" +
                "    <student ID=\"1\">\n" +
                "        <Nume>Adonis</Nume>\n" +
                "        <Grupa>931</Grupa>\n" +
                "    </student>\n" +
                "</Entitati>\n");
        writer.close();

        writer = new PrintWriter("testTeme.xml");
        writer.print("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" +
                "<Entitati>\n" +
                    "<tema ID=\"1\">\n" +
                        "<Descriere>File</Descriere>\n" +
                        "<Deadline>7</Deadline>\n" +
                        "<Startline>6</Startline>\n" +
                "</tema>\n" +
                "</Entitati>\n");
        writer.close();

        writer = new PrintWriter("testNote.xml");
        writer.print("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n" +
                "<Entitati>\n" +
                "</Entitati>\n");
        writer.close();

        StudentXMLRepository fileRepository1 = new StudentXMLRepository(studentValidator, "testStudenti.xml");

        TemaXMLRepository fileRepository2 = new TemaXMLRepository(temaValidator, "testTeme.xml");
        NotaXMLRepository fileRepository3 = new NotaXMLRepository(notaValidator, "testNote.xml");

        service = new Service(fileRepository1, fileRepository2, fileRepository3);
    }

    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }

    @Test
    public void testAdd1() {
        Validator<Student> studentValidator = new StudentValidator();
        StudentXMLRepository fileRepository1 = new StudentXMLRepository(studentValidator, "studenti.xml");
        fileRepository1.save(new Student("10", "Alex", 931));
        assertEquals("Alex", fileRepository1.findOne("10").getNume());
    }

    @Test
    public void testAdd2()
    {
        Validator<Student> studentValidator = new StudentValidator();
        StudentXMLRepository fileRepository1 = new StudentXMLRepository(studentValidator, "studenti.xml");
        Student s = fileRepository1.save(new Student("10", "", 931));
        assertNull(s);
    }

    @Test
    public void testTC1(){
        assertEquals(1, service.saveStudent("foobar", "的", 931));
    }

    @Test
    public void testTC2(){
        assertEquals(0, service.saveStudent("1", "的", 931));
    }

    @Test
    public void testTC3(){
        assertEquals(0, service.saveStudent("", "的", 931));
    }

    @Test
    public void testTC4(){
        assertEquals(0, service.saveStudent(null, "的", 931));
    }

    @Test
    public void testTC5(){
        assertEquals(0, service.saveStudent("f", "的", -1));
    }

    @Test
    public void testTC6(){
        assertEquals(0, service.saveStudent("f00bar", "的", 110));
    }

    @Test
    public void testTC7(){
        assertEquals(1, service.saveStudent("f0@b*r", "的", 111));
    }

    @Test
    public void testTC8(){
        assertEquals(1, service.saveStudent("f", "的", 112));
    }

    @Test
    public void testTC9() {
        assertEquals(1, service.saveStudent("popey", "的", 936));
    }

    @Test
    public void testTC10() {
        assertEquals(1, service.saveStudent("fa", "的", 937));
    }

    @Test
    public void testTC11() {
        assertEquals(0, service.saveStudent("pixel", "的", 938));
    }

    @Test
    public void testTC12() {
        assertEquals(0, service.saveStudent("gamma", "的", Integer.parseInt("400.13")));
    }

    @Test
    public void testTC13() {
        assertEquals(0, service.saveStudent("tesla", "的", Integer.parseInt("4000000000")));
    }

    @Test
    public void testTC14() {
        assertEquals(0, service.saveStudent("ford", "的", Integer.parseInt(null)));
    }

    @Test
    public void testTC15() {
        assertEquals(0, service.saveStudent("jet", null, 110));
    }

    @Test
    public void testTC16() {
        assertEquals(0, service.saveStudent("candy", "", 110));
    }

    @Test
    public void testAddAssignment1(){
        assertEquals(1, service.saveTema("2", "Setup", 7, 5));
    }

    @Test
    public void testAddAssignment2(){
        assertEquals(0, service.saveTema("2", null, 7, 5));
    }
}
