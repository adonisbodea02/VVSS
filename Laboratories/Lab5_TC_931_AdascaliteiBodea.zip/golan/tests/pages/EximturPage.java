package MySerenityJUnitArchetypeG.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

@DefaultUrl("https://www.eximtur.ro/")
public class EximturPage extends PageObject {

    @FindBy(name="Destination")
    private WebElementFacade destinationSelect;

    @FindBy(name="DepCityCode")
    private WebElementFacade departureCitySelect;

    @FindBy(name="CheckIn")
    private WebElementFacade departureDateSelect;

    @FindBy(name="CheckOut")
    private WebElementFacade returnDateSelect;

    @FindBy(xpath = "//button[text()='Cauta']")
    private WebElementFacade searchButton;

    public void selectDestination(int index) {
        destinationSelect.selectByIndex(index);
    }

    public void selectDepartureCity(int index) {
        departureCitySelect.selectByIndex(index);
    }

    public void selectFirstDepartureDateAvailable() {
        departureDateSelect.click();
        var date = find(By.xpath("//label[text()='Plecare']/..//td[not(contains(@class, ' disabled'))]/span"));
        date.click();
    }

    public void selectFirstReturnDateAvailable(){
        returnDateSelect.click();
        var date = find(By.xpath("//label[text()='Intoarcere']/..//td[not(contains(@class, ' disabled'))]/span"));
        date.click();
    }

    public void search() {
        searchButton.click();
    }

    public void checkAlertMessage(String message) {
    }

    public void checkNumberOfHotels(String foundHotels) {
        var number = find(By.xpath("//p[contains(@class, 'flights-count-text')]"));
        assertEquals(number.getText(), foundHotels);
    }
}