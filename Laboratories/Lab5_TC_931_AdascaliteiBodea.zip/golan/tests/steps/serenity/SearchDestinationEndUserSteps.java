package MySerenityJUnitArchetypeG.steps.serenity;

import MySerenityJUnitArchetypeG.pages.EximturPage;
import net.thucydides.core.annotations.Step;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;

public class SearchDestinationEndUserSteps {

    private EximturPage eximturPage;

    @Step
    public void openPage() {
        eximturPage.open();
    }

    @Step
    public void selectDestination(int index) {
        eximturPage.selectDestination(index);
    }

    @Step
    public void selectDepartureCity(int index) {
        eximturPage.selectDepartureCity(index);
    }

    @Step
    public void selectDepartureDate() {
        eximturPage.selectFirstDepartureDateAvailable();
    }

    @Step
    public void selectReturnDate() {
        eximturPage.selectFirstReturnDateAvailable();
    }

    @Step
    public void search() {
        eximturPage.search();
    }

    @Step
    public void checkPopupAlertMessage(String message) {
        eximturPage.checkAlertMessage(message);
    }

    @Step
    public void checkNumberOfHotels(String foundHotels) {
        eximturPage.checkNumberOfHotels(foundHotels);
    }
}