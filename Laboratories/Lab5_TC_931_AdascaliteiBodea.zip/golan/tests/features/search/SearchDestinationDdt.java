package MySerenityJUnitArchetypeG.features.search;

import MySerenityJUnitArchetypeG.steps.serenity.SearchDestinationEndUserSteps;
import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.ManagedPages;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.pages.Pages;
import net.thucydides.junit.annotations.Qualifier;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/searchDestination.csv")
public class SearchDestinationDdt {

    @Managed(uniqueSession = true)
    public WebDriver webDriver;

    @ManagedPages(defaultUrl = "https://www.eximtur.ro/")
    public Pages pages;

    @Steps
    public SearchDestinationEndUserSteps searchDestinationEndUserSteps;

    public int destination;
    public int departureCity;
    public String result;

    @Qualifier
    public String getQualifier() {
        return String.valueOf(this.destination);
    }

    @Issue("#EXIMTUR-1")
    @Test
    public void searchDestination_incompleteData() {
        searchDestinationEndUserSteps.openPage();
        searchDestinationEndUserSteps.selectDestination(getDestination());
        searchDestinationEndUserSteps.selectDepartureCity(getDepartureCity());
        searchDestinationEndUserSteps.search();
        searchDestinationEndUserSteps.checkPopupAlertMessage(getResult());
    }

    @Issue("#EXIMTUR-2")
    @Test
    public void searchDestination_completeData() {
        searchDestinationEndUserSteps.openPage();
        searchDestinationEndUserSteps.selectDestination(getDestination());
        searchDestinationEndUserSteps.selectDepartureCity(getDepartureCity());
        searchDestinationEndUserSteps.selectDepartureDate();
        searchDestinationEndUserSteps.selectReturnDate();
        searchDestinationEndUserSteps.search();
        searchDestinationEndUserSteps.checkNumberOfHotels(getResult());
    }

    public int getDestination() {
        return this.destination;
    }

    public void setDestination(int destination) {
        this.destination = destination;
    }

    public int getDepartureCity() {
        return this.destination;
    }

    public void setDepartureCity(int departureCity) {
        this.departureCity = departureCity;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}